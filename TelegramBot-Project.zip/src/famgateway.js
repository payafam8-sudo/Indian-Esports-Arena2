'use strict';

// IMPORTANT:
// FamGateway's exact API endpoint, request fields, authentication header,
// response format, webhook event and signature algorithm must come from its
// official documentation. This adapter intentionally fails closed until those
// details are supplied. Do not guess these values or mark payments as paid
// based on a browser redirect or a Telegram button click.

async function createOrder({ orderId, amount, customer }) {
  const apiKey = process.env.FAMGATEWAY_API_KEY;
  const endpoint = process.env.FAMGATEWAY_CREATE_ORDER_URL;

  if (!apiKey || !endpoint) {
    throw new Error('FamGateway is not configured: API key or create-order URL missing.');
  }

  // Implement this request from the official FamGateway documentation.
  // Expected normalized return shape:
  // { providerOrderId: string, checkoutUrl?: string, qrCodeUrl?: string }
  throw new Error(
    'FamGateway createOrder adapter needs the official API documentation. ' +
    'Do not remove this guard or simulate a successful payment.'
  );
}

function verifyWebhook(headers, rawBody) {
  const secret = process.env.FAMGATEWAY_WEBHOOK_SECRET;
  if (!secret || !Buffer.isBuffer(rawBody)) return null;

  // Implement the provider's documented signature verification here.
  // Return only a normalized, cryptographically verified event:
  // { orderId, providerOrderId, status, amount, currency }
  // Returning null keeps the endpoint fail-closed until implemented.
  return null;
}

module.exports = { createOrder, verifyWebhook };
