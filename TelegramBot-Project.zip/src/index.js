'use strict';

require('dotenv').config();

const express = require('express');
const TelegramBot = require('node-telegram-bot-api');
const admin = require('firebase-admin');
const path = require('path');
const gateway = require('./famgateway');

const required = ['TELEGRAM_BOT_TOKEN', 'FIREBASE_DATABASE_URL', 'FIREBASE_SERVICE_ACCOUNT_PATH'];
for (const key of required) {
  if (!process.env[key]) {
    console.error(`Missing required environment variable: ${key}`);
    process.exit(1);
  }
}

const serviceAccountPath = path.resolve(process.env.FIREBASE_SERVICE_ACCOUNT_PATH);
const serviceAccount = require(serviceAccountPath);

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: process.env.FIREBASE_DATABASE_URL
});

const db = admin.database();
const bot = new TelegramBot(process.env.TELEGRAM_BOT_TOKEN, { polling: true });
const app = express();

// Keep the raw body for provider-specific signature verification.
// Do not trust webhook JSON until the signature has been verified.
app.use('/webhooks/famgateway', express.raw({ type: '*/*' }));
app.use(express.json());

const amountStates = new Map();
const MIN_AMOUNT = 1;
const MAX_AMOUNT = 100000;

function userKey(telegramId) {
  return String(telegramId);
}

async function ensureUser(from) {
  const ref = db.ref(`users/${userKey(from.id)}`);
  await ref.transaction(current => {
    if (current) return current;
    return {
      telegramId: from.id,
      username: from.username || null,
      firstName: from.first_name || null,
      balance: 0,
      createdAt: admin.database.ServerValue.TIMESTAMP
    };
  });
  return ref;
}

function parseAmount(text) {
  if (typeof text !== 'string') return null;
  const normalized = text.trim();
  // Accept only a positive decimal amount with at most 2 decimal places.
  if (!/^(?:\d{1,6})(?:\.\d{1,2})?$/.test(normalized)) return null;
  const amount = Number(normalized);
  if (!Number.isFinite(amount) || amount < MIN_AMOUNT || amount > MAX_AMOUNT) return null;
  return Math.round(amount * 100) / 100;
}

bot.onText(/^\/start(?:@\w+)?$/, async (msg) => {
  const chatId = msg.chat.id;
  try {
    await ensureUser(msg.from);
    await bot.sendMessage(
      chatId,
      'Your Telegram account is registered. Use /addbalance to create a payment request.'
    );
  } catch (err) {
    console.error('Start/register error:', err);
    await bot.sendMessage(chatId, 'Could not register your account right now. Please try again later.');
  }
});

bot.onText(/^\/cancel(?:@\w+)?$/, async (msg) => {
  amountStates.delete(msg.from.id);
  await bot.sendMessage(msg.chat.id, 'Current action cancelled.');
});

bot.onText(/^\/addbalance(?:@\w+)?$/, async (msg) => {
  try {
    await ensureUser(msg.from);
    amountStates.set(msg.from.id, true);
    await bot.sendMessage(
      msg.chat.id,
      `Enter an amount between ₹${MIN_AMOUNT} and ₹${MAX_AMOUNT}. Send /cancel to stop.`
    );
  } catch (err) {
    console.error('Add balance start error:', err);
    await bot.sendMessage(msg.chat.id, 'Could not start a payment request. Please try again later.');
  }
});

bot.on('message', async (msg) => {
  if (!msg.text || msg.text.startsWith('/')) return;
  if (!amountStates.has(msg.from.id)) return;

  const amount = parseAmount(msg.text);
  if (amount === null) {
    await bot.sendMessage(msg.chat.id, 'Invalid amount. Enter a valid positive amount, e.g. 100 or 99.50.');
    return;
  }

  amountStates.delete(msg.from.id);
  const orderId = `TG${msg.from.id}_${Date.now()}`;
  const paymentRef = db.ref(`payments/${orderId}`);

  try {
    // Create a pending record before calling the provider.
    await paymentRef.set({
      orderId,
      telegramId: msg.from.id,
      amount,
      currency: 'INR',
      status: 'creating',
      createdAt: admin.database.ServerValue.TIMESTAMP
    });

    // This adapter intentionally refuses to invent FamGateway API details.
    const order = await gateway.createOrder({
      orderId,
      amount,
      customer: {
        telegramId: msg.from.id,
        username: msg.from.username || null
      }
    });

    await paymentRef.update({
      status: 'pending',
      providerOrderId: order.providerOrderId,
      checkoutUrl: order.checkoutUrl || null,
      qrCodeUrl: order.qrCodeUrl || null,
      updatedAt: admin.database.ServerValue.TIMESTAMP
    });

    const buttons = [];
    if (order.checkoutUrl) {
      buttons.push([{ text: 'Pay now', url: order.checkoutUrl }]);
    }
    buttons.push([{ text: 'Check payment status', callback_data: `check:${orderId}` }]);

    const message = [
      `Payment order created for ₹${amount.toFixed(2)}.`,
      `Order ID: ${orderId}`,
      order.checkoutUrl ? 'Tap “Pay now” to complete payment.' : 'Use the payment QR shown by the gateway, if provided.',
      'Balance is added only after a verified gateway webhook.'
    ].join('\n');

    if (order.qrCodeUrl) {
      await bot.sendPhoto(msg.chat.id, order.qrCodeUrl, {
        caption: message,
        reply_markup: { inline_keyboard: buttons }
      });
    } else {
      await bot.sendMessage(msg.chat.id, message, {
        reply_markup: { inline_keyboard: buttons }
      });
    }
  } catch (err) {
    console.error('Create payment order error:', err);
    await paymentRef.update({
      status: 'creation_failed',
      error: 'Gateway order creation failed or gateway configuration is incomplete.',
      updatedAt: admin.database.ServerValue.TIMESTAMP
    }).catch(() => {});
    await bot.sendMessage(
      msg.chat.id,
      'Payment gateway is not configured yet. No money has been charged. Add the official FamGateway API details, then try again.'
    );
  }
});

bot.on('callback_query', async (query) => {
  try {
    const data = query.data || '';
    if (!data.startsWith('check:')) return;
    const orderId = data.slice('check:'.length);
    const snapshot = await db.ref(`payments/${orderId}`).once('value');
    const payment = snapshot.val();

    if (!payment || payment.telegramId !== query.from.id) {
      await bot.answerCallbackQuery(query.id, { text: 'Payment order not found.' });
      return;
    }

    await bot.answerCallbackQuery(query.id);
    if (payment.status === 'paid') {
      await bot.sendMessage(query.message.chat.id, `Payment confirmed. ₹${Number(payment.amount).toFixed(2)} has been credited.`);
    } else {
      await bot.sendMessage(query.message.chat.id, `Current payment status: ${payment.status}. Balance is credited only after verified confirmation.`);
    }
  } catch (err) {
    console.error('Payment status check error:', err);
    await bot.answerCallbackQuery(query.id, { text: 'Could not check status. Try again.' }).catch(() => {});
  }
});

// Provider webhook endpoint. Must be completed using FamGateway's official
// signature scheme and exact event/payload format before accepting live payments.
app.post('/webhooks/famgateway', async (req, res) => {
  try {
    const verifiedEvent = gateway.verifyWebhook(req.headers, req.body);
    if (!verifiedEvent) {
      return res.status(401).send('Invalid or unconfigured webhook signature');
    }

    const { orderId, providerOrderId, status, amount, currency } = verifiedEvent;
    if (!orderId || status !== 'paid' || currency !== 'INR' || !Number.isFinite(Number(amount))) {
      return res.status(400).send('Invalid payment event');
    }

    const paymentRef = db.ref(`payments/${orderId}`);
    const paymentSnapshot = await paymentRef.once('value');
    const payment = paymentSnapshot.val();

    if (!payment) return res.status(404).send('Unknown order');
    if (Number(payment.amount) !== Number(amount) || payment.currency !== currency) {
      return res.status(400).send('Payment amount/currency mismatch');
    }

    // Atomic idempotency guard: only the first verified paid event changes status.
    const result = await paymentRef.transaction(current => {
      if (!current || current.status === 'paid') return;
      current.status = 'paid';
      current.providerOrderId = providerOrderId || current.providerOrderId || null;
      current.paidAt = admin.database.ServerValue.TIMESTAMP;
      return current;
    });

    if (result.committed && result.snapshot.val().status === 'paid') {
      const userRef = db.ref(`users/${userKey(payment.telegramId)}`);
      const creditRef = db.ref(`paymentCredits/${orderId}`);
      const creditResult = await creditRef.transaction(current => {
        if (current) return;
        return {
          telegramId: payment.telegramId,
          amount: Number(payment.amount),
          creditedAt: admin.database.ServerValue.TIMESTAMP
        };
      });

      if (creditResult.committed) {
        await userRef.child('balance').transaction(current => {
          const balance = Number(current || 0);
          return Math.round((balance + Number(payment.amount)) * 100) / 100;
        });
        await bot.sendMessage(
          payment.telegramId,
          `Payment received. ₹${Number(payment.amount).toFixed(2)} has been added to your balance.`
        ).catch(err => console.error('Telegram notification error:', err));
      }
    }

    return res.status(200).send('OK');
  } catch (err) {
    console.error('Webhook processing error:', err);
    return res.status(500).send('Webhook processing failed');
  }
});

app.get('/health', (_req, res) => res.json({ ok: true }));

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Webhook server listening on port ${port}`));

bot.on('polling_error', err => console.error('Telegram polling error:', err));
process.on('unhandledRejection', err => console.error('Unhandled rejection:', err));
