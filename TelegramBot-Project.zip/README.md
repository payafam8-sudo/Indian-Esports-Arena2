# Telegram + Firebase + FamGateway bot

## Included
- Telegram `/start`, `/addbalance`, and `/cancel`
- Firebase Realtime Database user/payment records
- Amount validation and per-user input state
- Payment status button
- Webhook endpoint with an idempotency guard
- No random/simulated payment success

## Important: FamGateway is not yet live-connected
The exact FamGateway API request and webhook signature cannot safely be guessed.
`src/famgateway.js` deliberately fails closed until you receive the official
FamGateway documentation. Until then, order creation and webhook verification
will not claim a payment succeeded or credit a balance.

When you receive the docs, implement:
1. `createOrder()` using the documented URL, headers, request body and response.
2. `verifyWebhook()` using the documented signature algorithm and raw request body.
3. Map the provider's verified webhook payload to:
   `{ orderId, providerOrderId, status, amount, currency }`.

Never credit based on a redirect, screenshot, QR scan, or the Telegram status button.

## Setup
1. Install Node.js 18 or newer.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and fill in your Telegram token and Firebase settings.
4. Download a Firebase Admin service-account JSON from your Firebase project and
   save it as `serviceAccountKey.json` in this folder (or set its path in `.env`).
5. Add `serviceAccountKey.json` to `.gitignore` (already included).
6. Run `npm start`.

## Webhook deployment
Deploy this Node app on a public HTTPS host and set the provider webhook URL to:
`https://YOUR_DOMAIN/webhooks/famgateway`

The endpoint is not ready to accept live FamGateway payments until
`verifyWebhook()` and `createOrder()` are implemented from official docs.

## Firebase data layout
- `users/{telegramId}`: profile and balance
- `payments/{orderId}`: payment order state
- `paymentCredits/{orderId}`: one-time credit marker

## Security notes
- Do not share your Telegram bot token, Firebase service-account JSON, API key,
  or webhook secret.
- The Telegram token shared in chat should be revoked in BotFather and replaced.
- Apply Firebase Realtime Database security rules appropriate for your app.
- For production, add request rate limits, monitoring, HTTPS, and a durable
  webhook retry/reconciliation process.
